package co.edu.unbosque.CarrenoJuan_Prog2.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.CarrenoJuan_Prog2.model.Animal;

public interface AnimalRepository extends CrudRepository<Animal, Integer>{

}
